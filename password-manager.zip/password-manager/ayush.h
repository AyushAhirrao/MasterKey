char encrypt_string(char *string)
{
    char *ptr = string;
    int i = 0;
    while (string[i] != '\0')
    {
        *ptr = *ptr + 1;
        ptr++;
        i++;
    }

    strrev(string);
}

char decrypt_string(char *string)
{
    char *ptr = string;
    int i = 0;
    strrev(string);
    while (string[i] != '\0')
    {
        *ptr = *ptr - 1;
        ptr++;
        i++;
    }
}
